def test():
    print('test package')